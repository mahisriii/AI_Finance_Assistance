const API_URL = (import.meta.env && import.meta.env.VITE_API_URL) || "http://localhost:8000";
let token = globalThis.localStorage?.getItem("finance_token") || null;

export function setToken(value) {
  token = value;
  if (value) globalThis.localStorage?.setItem("finance_token", value);
  else globalThis.localStorage?.removeItem("finance_token");
}

export async function api(path, options = {}) {
  const headers = { "Content-Type": "application/json", ...options.headers };
  if (token) headers.Authorization = `Bearer ${token}`;
  const response = await fetch(`${API_URL}/api${path}`, { ...options, headers });
  if (response.status === 204) return null;
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.detail || "Something went wrong");
  return data;
}

export function today() {
  return new Date().toISOString().slice(0, 10);
}
export function currentMonth() {
  return new Date().toISOString().slice(0, 7);
}
