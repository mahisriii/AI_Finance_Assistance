import { useEffect, useMemo, useState } from "react";
import {
  ArrowDownLeft, ArrowUpRight, Bot, ChevronDown, CircleHelp, LayoutDashboard,
  LogOut, Plus, ReceiptText, Sparkles, Wallet, X,
} from "lucide-react";
import {
  Area, AreaChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer,
  Tooltip, XAxis, YAxis,
} from "recharts";
import { api, currentMonth, setToken, today } from "../api";

const money = (n) => new Intl.NumberFormat(undefined, { style: "currency", currency: "USD" }).format(n || 0);
const navItems = [
  ["Overview", LayoutDashboard], ["Transactions", ReceiptText], ["Budgets", Wallet],
  ["Insights", Sparkles], ["Help", CircleHelp],
];
const colors = ["#317b67", "#e2a35f", "#7189bc", "#cb7666", "#9d83bb", "#6ea5a1"];

export default function App() {
  const [user, setUser] = useState(null);
  const [page, setPage] = useState("Overview");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    if (localStorage.getItem("finance_token")) api("/auth/me").then(setUser).catch(() => setToken(null));
  }, []);
  async function authenticate(mode, email, password) {
    setBusy(true);
    try {
      const result = await api(`/auth/${mode}`, { method: "POST", body: JSON.stringify({ email, password }) });
      setToken(result.access_token); setUser(result.user); setNotice("");
    } catch (e) { setNotice(e.message); }
    finally { setBusy(false); }
  }
  function logout() { setToken(null); setUser(null); setPage("Overview"); }
  if (!user) return <AuthScreen onAuth={authenticate} busy={busy} notice={notice} />;
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <a className="brand" href="#" onClick={() => setPage("Overview")}><span className="brand-mark">p.</span><span>pennywise<small>YOUR MONEY, IN FOCUS</small></span></a>
        <div className="workspace-label">WORKSPACE</div>
        <nav>{navItems.map(([name, Icon]) => <button key={name} className={`nav-link ${page === name ? "active" : ""}`} onClick={() => setPage(name)}><Icon size={18}/>{name}{name === "Help" && <span className="nav-new">ASK</span>}</button>)}</nav>
        <div className="sidebar-bottom"><div className="privacy-note"><span className="privacy-dot"/>Private by design<small>Your data stays on this device</small></div><button className="user-chip" onClick={logout}><span className="avatar">{user.email[0].toUpperCase()}</span><span className="user-email">{user.email}<small>Personal workspace</small></span><LogOut size={16}/></button></div>
      </aside>
      <main className="main-area">
        <header className="topbar"><span className="breadcrumb">Workspace <span>/</span> {page}</span><div className="top-actions"><span className="today-pill">{new Date().toLocaleDateString(undefined,{month:"short",day:"numeric",year:"numeric"})}</span><span className="avatar">{user.email[0].toUpperCase()}</span></div></header>
        {notice && <div className="toast error">{notice}<button onClick={() => setNotice("")}><X size={15}/></button></div>}
        <section className="page-content">
          {page === "Overview" && <Dashboard />}
          {page === "Transactions" && <Transactions onNotice={setNotice}/>}
          {page === "Budgets" && <Budgets onNotice={setNotice}/>}
          {page === "Insights" && <Insights />}
          {page === "Help" && <Help />}
          <footer className="disclaimer"><span>✳</span> For educational purposes only. This app is not professional financial advice.</footer>
        </section>
      </main>
    </div>
  );
}

function PageTitle({ eyebrow, title, subtitle, action }) {
  return <div className="page-title"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{subtitle}</p></div>{action}</div>;
}
function useLoad(path, deps = []) {
  const [data, setData] = useState(null), [error, setError] = useState("");
  const refresh = () => api(path).then(setData).catch(e => setError(e.message));
  useEffect(() => { refresh(); }, deps);
  return [data, refresh, error];
}
function Dashboard() {
  const [data, , error] = useLoad("/dashboard");
  const [forecast] = useLoad("/forecast");
  const totals = data || {income:0,expenses:0,balance:0,category_totals:[],monthly_spending:[]};
  return <>
    <PageTitle eyebrow="YOUR FINANCIAL SNAPSHOT" title="Good to see you." subtitle="Here's a clear look at your money this month." action={<span className="period-pill"><span/> This month <ChevronDown size={15}/></span>}/>
    {error && <p className="empty-note">{error}</p>}
    <div className="stat-grid">
      <Stat label="INCOME THIS MONTH" amount={totals.income} icon={ArrowDownLeft} tone="green" foot="Recorded income"/>
      <Stat label="SPENT THIS MONTH" amount={totals.expenses} icon={ArrowUpRight} tone="orange" foot="Recorded expenses"/>
      <Stat label="MONTHLY BALANCE" amount={totals.balance} icon={Wallet} tone="blue" foot="Income minus expenses"/>
    </div>
    <div className="chart-grid">
      <div className="card chart-card"><div className="card-heading"><div><h2>Spending over time</h2><p>Your recorded monthly expenses</p></div><span className="legend"><i/> Spending</span></div>
        {totals.monthly_spending.length ? <ResponsiveContainer width="100%" height={230}><AreaChart data={totals.monthly_spending}><defs><linearGradient id="spendFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#55957e" stopOpacity={.23}/><stop offset="100%" stopColor="#55957e" stopOpacity={0}/></linearGradient></defs><CartesianGrid vertical={false} stroke="#edf0ec"/><XAxis dataKey="month" axisLine={false} tickLine={false} tick={{fill:"#8c9791",fontSize:11}}/><YAxis axisLine={false} tickLine={false} tick={{fill:"#8c9791",fontSize:11}} tickFormatter={v=>`$${v}`}/><Tooltip formatter={v=>money(v)}/><Area type="monotone" dataKey="amount" stroke="#317b67" strokeWidth={2.5} fill="url(#spendFill)"/></AreaChart></ResponsiveContainer> : <EmptyState text="Add expense transactions to see your spending trend."/>}
      </div>
      <div className="card chart-card"><div className="card-heading"><div><h2>Where it goes</h2><p>Expense categories, all time</p></div></div>
        {totals.category_totals.length ? <div className="donut-wrap"><ResponsiveContainer width="100%" height={200}><PieChart><Pie data={totals.category_totals} dataKey="amount" nameKey="category" innerRadius={58} outerRadius={82} paddingAngle={3}>{totals.category_totals.map((_,i)=><Cell key={i} fill={colors[i%colors.length]}/>)}</Pie><Tooltip formatter={v=>money(v)}/></PieChart></ResponsiveContainer><div className="category-list">{totals.category_totals.slice(0,5).map((c,i)=><div key={c.category}><i style={{background:colors[i%colors.length]}}/>{c.category}<b>{money(c.amount)}</b></div>)}</div></div> : <EmptyState text="Your category breakdown will show here."/>}
      </div>
    </div>
    <div className="card forecast-card"><div className="forecast-icon"><Sparkles size={19}/></div><div><h3>Your spending outlook</h3><p>{forecast?.available ? `Recent monthly average: ${money(forecast.estimate)} · Based on ${forecast.based_on.join(", ")}` : forecast?.message || "Checking your recorded history…"}</p><small>A simple educational estimate, not financial advice.</small></div><span className="forecast-tag">{forecast?.available ? "3-MONTH AVERAGE" : "BUILDING HISTORY"}</span></div>
  </>;
}
function Stat({label,amount,icon:Icon,tone,foot}) {
  return <div className="card stat-card"><div className="stat-top"><span>{label}</span><i className={`stat-icon ${tone}`}><Icon size={18}/></i></div><strong>{money(amount)}</strong><small>{foot}</small></div>;
}
function EmptyState({text}) { return <div className="empty-state"><span>◌</span>{text}</div>; }

const categoryOptions = ["Other","Groceries","Dining","Transport","Housing","Shopping","Health","Entertainment","Utilities","Income"];
function Transactions({onNotice}) {
  const [rows, reload, error] = useLoad("/transactions");
  const [filter,setFilter] = useState("all"), [search,setSearch] = useState(""), [modal,setModal] = useState(false), [edit,setEdit] = useState(null);
  const [form,setForm] = useState({amount:"",date:today(),description:"",type:"expense",category:"Other"});
  const [suggestion,setSuggestion] = useState("");
  const filtered = useMemo(()=> (rows||[]).filter(r => (filter==="all"||r.type===filter) && `${r.description} ${r.category}`.toLowerCase().includes(search.toLowerCase())),[rows,filter,search]);
  function start(item=null) { setEdit(item);setForm(item?{...item,amount:String(item.amount)}:{amount:"",date:today(),description:"",type:"expense",category:"Other"});setSuggestion("");setModal(true); }
  async function suggest() {
    if(!form.description.trim()) return;
    try { const result=await api(`/categories/suggest?description=${encodeURIComponent(form.description)}`); setSuggestion(result.category); if(form.category==="Other") setForm(f=>({...f,category:result.category})); }
    catch(e){onNotice(e.message);}
  }
  async function submit(e) { e.preventDefault(); try { await api(edit?`/transactions/${edit.id}`:"/transactions",{method:edit?"PUT":"POST",body:JSON.stringify({...form,amount:Number(form.amount)})});setModal(false);reload(); } catch(e){onNotice(e.message);} }
  async function remove(id) { if(!confirm("Delete this transaction?")) return;try{await api(`/transactions/${id}`,{method:"DELETE"});reload();}catch(e){onNotice(e.message);} }
  return <>
    <PageTitle eyebrow="YOUR ACTIVITY" title="Transactions" subtitle="Keep track of the money coming in and going out." action={<button className="button primary" onClick={()=>start()}><Plus size={17}/> Add transaction</button>}/>
    <div className="toolbar"><div className="searchbox"><span>⌕</span><input aria-label="Search transactions" placeholder="Search transactions..." value={search} onChange={e=>setSearch(e.target.value)}/></div><div className="filter-tabs">{["all","expense","income"].map(x=><button key={x} className={filter===x?"selected":""} onClick={()=>setFilter(x)}>{x[0].toUpperCase()+x.slice(1)}</button>)}</div></div>
    <div className="card table-card">{error&&<p className="empty-note">{error}</p>}<table><thead><tr><th>TRANSACTION</th><th>CATEGORY</th><th>DATE</th><th>TYPE</th><th className="right">AMOUNT</th><th/></tr></thead><tbody>
      {filtered.map(r=><tr key={r.id}><td><div className="transaction-name"><span className={`transaction-icon ${r.type}`}>{r.type==="income"?<ArrowDownLeft size={17}/>:<ArrowUpRight size={17}/>}</span>{r.description}</div></td><td><span className="category-pill">{r.category}</span></td><td>{new Date(`${r.date}T12:00:00`).toLocaleDateString(undefined,{month:"short",day:"numeric",year:"numeric"})}</td><td><span className={`type-label ${r.type}`}>{r.type}</span></td><td className={`right amount ${r.type}`}>{r.type==="income"?"+":"−"}{money(r.amount)}</td><td className="row-actions"><button onClick={()=>start(r)} aria-label="Edit transaction">Edit</button><button onClick={()=>remove(r.id)} aria-label="Delete transaction">×</button></td></tr>)}
      {!filtered.length&&<tr><td colSpan="6"><EmptyState text="No transactions found. Add your first one to get started."/></td></tr>}
    </tbody></table><div className="table-foot">Showing {filtered.length} transaction{filtered.length===1?"":"s"}</div></div>
    {modal&&<div className="modal-backdrop" onMouseDown={e=>e.target===e.currentTarget&&setModal(false)}><form className="modal" onSubmit={submit}><div className="modal-head"><div><div className="eyebrow">{edit?"EDIT ENTRY":"NEW ENTRY"}</div><h2>{edit?"Update transaction":"Add transaction"}</h2></div><button type="button" className="icon-button" onClick={()=>setModal(false)}><X/></button></div>
      <label>What was it for?<input required maxLength="240" placeholder="e.g. Weekly grocery shop" value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/></label>
      <div className="form-row"><label>Amount<input required type="number" min="0.01" step="0.01" value={form.amount} onChange={e=>setForm({...form,amount:e.target.value})} placeholder="0.00"/></label><label>Date<input required type="date" value={form.date} onChange={e=>setForm({...form,date:e.target.value})}/></label></div>
      <div className="form-row"><label>Type<select value={form.type} onChange={e=>setForm({...form,type:e.target.value})}><option value="expense">Expense</option><option value="income">Income</option></select></label><label>Category<select value={form.category} onChange={e=>setForm({...form,category:e.target.value})}>{categoryOptions.map(c=><option key={c}>{c}</option>)}</select></label></div>
      {form.type==="expense"&&<button type="button" className="text-button" onClick={suggest}><Sparkles size={14}/> Suggest a category{suggestion&&<span> · Suggested: {suggestion}</span>}</button>}
      <div className="modal-actions"><button type="button" className="button secondary" onClick={()=>setModal(false)}>Cancel</button><button className="button primary">{edit?"Save changes":"Add transaction"}</button></div>
    </form></div>}
  </>;
}

function Budgets({onNotice}) {
  const [month,setMonth]=useState(currentMonth()),[items,reload,error]=useLoad(`/budgets?month=${month}`,[month]);
  const [open,setOpen]=useState(false),[amount,setAmount]=useState(""),[category,setCategory]=useState("");
  async function create(e){e.preventDefault();try{await api("/budgets",{method:"POST",body:JSON.stringify({month,amount:Number(amount),category:category||null})});setOpen(false);setAmount("");reload();}catch(e){onNotice(e.message);}}
  async function remove(id){try{await api(`/budgets/${id}`,{method:"DELETE"});reload();}catch(e){onNotice(e.message);}}
  return <>
    <PageTitle eyebrow="PLAN WITH CLARITY" title="Budgets" subtitle="Set a monthly guide for spending that matters to you." action={<button className="button primary" onClick={()=>setOpen(true)}><Plus size={17}/> Create budget</button>}/>
    <div className="budget-month"><label htmlFor="budget-month">MONTH</label><input id="budget-month" type="month" value={month} onChange={e=>setMonth(e.target.value)}/></div>
    {error&&<p className="empty-note">{error}</p>}
    <div className="budget-grid">{(items||[]).map(b=>{const pct=Math.min(100,b.spent/b.amount*100);return <div className="card budget-card" key={b.id}><div className="budget-title"><span className="budget-icon"><Wallet size={18}/></span><div><h3>{b.category||"Overall spending"}</h3><small>{b.category?"Category budget":"Monthly budget"}</small></div><button className="icon-button" onClick={()=>remove(b.id)} aria-label="Delete budget"><X size={17}/></button></div><div className="budget-numbers"><strong>{money(b.spent)}</strong><span>of {money(b.amount)}</span></div><div className="progress-track"><div className={`progress-fill ${b.over_limit?"over":""}`} style={{width:`${pct}%`}}/></div><div className={`budget-status ${b.over_limit?"over":""}`}>{b.over_limit?`Over by ${money(b.spent-b.amount)}`:`${Math.round(pct)}% used`}<span>{money(Math.max(0,b.amount-b.spent))} left</span></div></div>})}
      {!items?.length&&<div className="card budget-empty"><span className="empty-illustration"><Wallet size={23}/></span><h3>No budgets for this month yet</h3><p>Create a budget to keep an eye on spending.</p><button className="button primary" onClick={()=>setOpen(true)}><Plus size={16}/> Create a budget</button></div>}
    </div>
    {open&&<div className="modal-backdrop"><form className="modal" onSubmit={create}><div className="modal-head"><div><div className="eyebrow">PLAN AHEAD</div><h2>Create a budget</h2></div><button type="button" className="icon-button" onClick={()=>setOpen(false)}><X/></button></div><label>Monthly limit<input required type="number" min=".01" step=".01" value={amount} onChange={e=>setAmount(e.target.value)} placeholder="e.g. 1200"/></label><label>Category <span className="optional">(optional — leave empty for overall)</span><select value={category} onChange={e=>setCategory(e.target.value)}><option value="">All expenses</option>{categoryOptions.filter(x=>x!=="Income"&&x!=="Other").map(c=><option key={c}>{c}</option>)}</select></label><div className="modal-actions"><button type="button" className="button secondary" onClick={()=>setOpen(false)}>Cancel</button><button className="button primary">Save budget</button></div></form></div>}
  </>;
}

function Insights() {
  const [data,,error]=useLoad("/insights");
  return <><PageTitle eyebrow="LEARN FROM YOUR HABITS" title="Spending insights" subtitle="Simple observations grounded in the transactions you've recorded."/><div className="insight-intro"><span><Sparkles size={19}/></span><div><b>A little perspective goes a long way.</b><p>These observations describe your data; they don't tell you what to do with your money.</p></div></div>{error&&<p className="empty-note">{error}</p>}
    <div className="insight-list">{(data?.insights||[]).map((i,n)=><article className="card insight-card" key={n}><span className="insight-number">0{n+1}</span><div><h3>{i.title}</h3><p>{i.text}</p></div></article>)}{data&&!data.insights.length&&<div className="card empty-card"><div className="empty-illustration"><Sparkles size={22}/></div><h3>More data, more perspective</h3><p>Record transactions and set a budget to see useful observations here.</p></div>}</div><p className="fine-print">{data?.disclaimer||"Educational observations only; not professional financial advice."}</p>
  </>;
}

function Help() {
  const [messages,setMessages]=useState([{role:"assistant",text:"Hi there! I can help you find your way around pennywise. Ask me about transactions, budgets, categories, or the dashboard."}]);
  const [input,setInput]=useState(""),[busy,setBusy]=useState(false),[error,setError]=useState("");
  async function send(e){e?.preventDefault();if(!input.trim()||busy)return;const text=input.trim();setInput("");setMessages(m=>[...m,{role:"user",text}]);setBusy(true);setError("");try{const result=await api("/help/chat",{method:"POST",body:JSON.stringify({message:text})});setMessages(m=>[...m,{role:"assistant",text:result.answer}]);}catch(e){setError(e.message);}finally{setBusy(false);}}
  return <><PageTitle eyebrow="HERE TO HELP" title="Ask pennywise" subtitle="A friendly guide to using the app and understanding its tools."/>
    <div className="chat-card card"><div className="chat-head"><span className="bot-avatar"><Bot size={19}/></span><div><b>Pennywise guide</b><small><i/> App help &amp; general education</small></div><span className="scope-pill">LIMITED SCOPE</span></div><div className="chat-messages">{messages.map((m,i)=><div className={`message ${m.role}`} key={i}><span className="message-avatar">{m.role==="assistant"?<Bot size={15}/>: "Y"}</span><div>{m.text}</div></div>)}{busy&&<div className="message assistant"><span className="message-avatar"><Bot size={15}/></span><div className="typing">Thinking…</div></div>}</div>{error&&<p className="chat-error">{error}</p>}<form className="chat-compose" onSubmit={send}><input aria-label="Ask a question" value={input} onChange={e=>setInput(e.target.value)} placeholder="Ask about budgets, transactions..." maxLength="500"/><button className="button primary" disabled={!input.trim()||busy}>Send <ArrowUpRight size={15}/></button></form><div className="chat-disclaimer">I can explain app features, but I can't offer personal financial advice or make transactions.</div></div>
    <div className="suggested-questions"><span>TRY ASKING</span>{["How do budgets work?","How is my forecast calculated?","Can I change a category?"].map(q=><button key={q} onClick={()=>setInput(q)}>{q} ↗</button>)}</div>
  </>;
}

function AuthScreen({onAuth,busy,notice}) {
  const [mode,setMode]=useState("login"),[email,setEmail]=useState(""),[password,setPassword]=useState("");
  return <main className="auth-page"><div className="auth-decoration"><div className="auth-orbit orbit-one"/><div className="auth-orbit orbit-two"/><div className="auth-logo"><span className="brand-mark">p.</span></div><div className="auth-quote"><span>“</span><h2>A calmer relationship<br/>with your money.</h2><p>A little clarity today can make tomorrow feel lighter.</p></div><div className="auth-decoration-foot">YOUR PRIVATE FINANCIAL SPACE · BUILT FOR LEARNING</div></div><div className="auth-form-side"><div className="auth-form-wrap"><div className="mobile-brand"><span className="brand-mark">p.</span> pennywise</div><div className="eyebrow">WELCOME TO PENNYWISE</div><h1>{mode==="login"?"Welcome back.":"Create your space."}</h1><p className="auth-subtitle">{mode==="login"?"Sign in to pick up where you left off.":"A private place to understand your money."}</p>{notice&&<div className="auth-error">{notice}</div>}<form onSubmit={e=>{e.preventDefault();onAuth(mode,email,password);}}><label>Email address<input type="email" autoComplete="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com"/></label><label>Password<input type="password" autoComplete={mode==="login"?"current-password":"new-password"} minLength="8" required value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 8 characters"/></label><button className="button primary auth-submit" disabled={busy}>{busy?"One moment…":mode==="login"?"Sign in":"Create account"}<ArrowUpRight size={16}/></button></form><div className="auth-switch">{mode==="login"?"New to pennywise?":"Already have an account?"} <button onClick={()=>setMode(mode==="login"?"register":"login")}>{mode==="login"?"Create an account":"Sign in"}</button></div><div className="auth-privacy"><span>✳</span> Your financial data is private and protected.</div><div className="auth-legal">For educational purposes only. Not financial advice.</div></div></div></main>;
}
