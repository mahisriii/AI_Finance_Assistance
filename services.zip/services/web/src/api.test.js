import test from "node:test";
import assert from "node:assert/strict";

test("money/date helpers preserve expected display formats", async () => {
  const { today, currentMonth } = await import("./api.js");
  assert.match(today(), /^\d{4}-\d{2}-\d{2}$/);
  assert.match(currentMonth(), /^\d{4}-\d{2}$/);
});
