from collections import defaultdict
from datetime import date, datetime
from calendar import monthrange
import os

from fastapi import Depends, FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import select
from sqlalchemy.orm import Session

from .categorizer import suggest_category
from .database import Base, engine, get_db
from .models import Budget, Transaction, User
from .schemas import AuthOut, BudgetIn, BudgetOut, Credentials, TransactionIn, TransactionOut, UserOut
from .security import create_token, current_user, hash_password, verify_password

Base.metadata.create_all(bind=engine)
app = FastAPI(title="AI Finance Assistant API", version="1.0.0",
              description="Educational personal-finance tools; not professional financial advice.")
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS", "http://localhost:5173").split(","),
    allow_credentials=True, allow_methods=["*"], allow_headers=["*"],
)


@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.post("/api/auth/register", response_model=AuthOut, status_code=201)
def register(body: Credentials, db: Session = Depends(get_db)):
    email = body.email.lower()
    if db.scalar(select(User).where(User.email == email)):
        raise HTTPException(409, "An account with this email already exists")
    user = User(email=email, password_hash=hash_password(body.password))
    db.add(user)
    db.commit()
    db.refresh(user)
    return {"access_token": create_token(user.id), "user": user}


@app.post("/api/auth/login", response_model=AuthOut)
def login(body: Credentials, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == body.email.lower()))
    if not user or not verify_password(body.password, user.password_hash):
        raise HTTPException(401, "Email or password is incorrect")
    return {"access_token": create_token(user.id), "user": user}


@app.get("/api/auth/me", response_model=UserOut)
def me(user: User = Depends(current_user)):
    return user


@app.post("/api/categories/suggest")
def category_suggestion(description: str = Query(min_length=1, max_length=240),
                        _: User = Depends(current_user)):
    category, confidence = suggest_category(description)
    return {"category": category, "confidence": round(confidence, 3),
            "disclaimer": "Suggestions can be wrong; review or change the category."}


@app.get("/api/transactions", response_model=list[TransactionOut])
def list_transactions(search: str | None = None, type: str | None = None,
                      category: str | None = None, month: str | None = None,
                      db: Session = Depends(get_db), user: User = Depends(current_user)):
    query = select(Transaction).where(Transaction.user_id == user.id)
    if search:
        query = query.where(Transaction.description.ilike(f"%{search[:100]}%"))
    if type in ("income", "expense"):
        query = query.where(Transaction.type == type)
    if category:
        query = query.where(Transaction.category == category)
    if month:
        try:
            datetime.strptime(month, "%Y-%m")
        except ValueError:
            raise HTTPException(422, "month must use YYYY-MM")
        query = query.where(Transaction.date >= date.fromisoformat(month + "-01"))
        year, mon = map(int, month.split("-"))
        query = query.where(Transaction.date <= date(year, mon, monthrange(year, mon)[1]))
    return db.scalars(query.order_by(Transaction.date.desc(), Transaction.id.desc())).all()


@app.post("/api/transactions", response_model=TransactionOut, status_code=201)
def create_transaction(body: TransactionIn, db: Session = Depends(get_db),
                       user: User = Depends(current_user)):
    category = body.category
    if body.type == "expense" and category == "Other":
        suggested, confidence = suggest_category(body.description)
        if confidence >= 0.30:
            category = suggested
    item = Transaction(**body.model_dump(exclude={"category"}), category=category, user_id=user.id)
    db.add(item)
    db.commit()
    db.refresh(item)
    return item


def owned_transaction(transaction_id: int, db: Session, user_id: int):
    item = db.get(Transaction, transaction_id)
    if item is None or item.user_id != user_id:
        raise HTTPException(404, "Transaction not found")
    return item


@app.put("/api/transactions/{transaction_id}", response_model=TransactionOut)
def update_transaction(transaction_id: int, body: TransactionIn, db: Session = Depends(get_db),
                       user: User = Depends(current_user)):
    item = owned_transaction(transaction_id, db, user.id)
    for key, value in body.model_dump().items():
        setattr(item, key, value)
    db.commit()
    db.refresh(item)
    return item


@app.delete("/api/transactions/{transaction_id}", status_code=204)
def delete_transaction(transaction_id: int, db: Session = Depends(get_db),
                       user: User = Depends(current_user)):
    item = owned_transaction(transaction_id, db, user.id)
    db.delete(item)
    db.commit()


@app.get("/api/budgets")
def list_budgets(month: str | None = None, db: Session = Depends(get_db),
                 user: User = Depends(current_user)):
    month = month or date.today().strftime("%Y-%m")
    rows = db.scalars(select(Budget).where(Budget.user_id == user.id, Budget.month == month)).all()
    result = []
    for budget in rows:
        query = select(Transaction).where(Transaction.user_id == user.id,
            Transaction.type == "expense", Transaction.date >= date.fromisoformat(month + "-01"))
        year, mon = map(int, month.split("-"))
        query = query.where(Transaction.date <= date(year, mon, monthrange(year, mon)[1]))
        if budget.category:
            query = query.where(Transaction.category == budget.category)
        spent = sum(t.amount for t in db.scalars(query).all())
        result.append({"id": budget.id, "month": budget.month, "amount": budget.amount,
                       "category": budget.category, "spent": round(spent, 2),
                       "over_limit": spent > budget.amount})
    return result


@app.post("/api/budgets", response_model=BudgetOut, status_code=201)
def create_budget(body: BudgetIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    existing = db.scalar(select(Budget).where(Budget.user_id == user.id,
        Budget.month == body.month, Budget.category == body.category))
    if existing:
        raise HTTPException(409, "A budget already exists for this month and category")
    budget = Budget(**body.model_dump(), user_id=user.id)
    db.add(budget)
    db.commit()
    db.refresh(budget)
    return {**body.model_dump(), "id": budget.id, "spent": 0}


@app.delete("/api/budgets/{budget_id}", status_code=204)
def delete_budget(budget_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    budget = db.get(Budget, budget_id)
    if budget is None or budget.user_id != user.id:
        raise HTTPException(404, "Budget not found")
    db.delete(budget)
    db.commit()


def user_transactions(db: Session, user_id: int):
    return db.scalars(select(Transaction).where(Transaction.user_id == user_id)).all()


@app.get("/api/dashboard")
def dashboard(db: Session = Depends(get_db), user: User = Depends(current_user)):
    items = user_transactions(db, user.id)
    today = date.today()
    this_month = [t for t in items if t.date.year == today.year and t.date.month == today.month]
    income = sum(t.amount for t in this_month if t.type == "income")
    expenses = sum(t.amount for t in this_month if t.type == "expense")
    categories = defaultdict(float)
    monthly = defaultdict(float)
    for item in items:
        if item.type == "expense":
            categories[item.category] += item.amount
            monthly[item.date.strftime("%Y-%m")] += item.amount
    return {"income": round(income, 2), "expenses": round(expenses, 2),
            "balance": round(income - expenses, 2),
            "category_totals": [{"category": k, "amount": round(v, 2)}
                                for k, v in sorted(categories.items())],
            "monthly_spending": [{"month": k, "amount": round(v, 2)}
                                 for k, v in sorted(monthly.items())[-12:]]}


@app.get("/api/forecast")
def forecast(db: Session = Depends(get_db), user: User = Depends(current_user)):
    items = user_transactions(db, user.id)
    months = defaultdict(float)
    for t in items:
        if t.type == "expense":
            months[t.date.strftime("%Y-%m")] += t.amount
    if len(months) < 3:
        return {"available": False, "months_of_history": len(months),
                "message": "Add expenses across at least 3 different months to see an estimate."}
    recent = sorted(months.items())[-3:]
    return {"available": True, "months_of_history": len(months),
            "estimate": round(sum(amount for _, amount in recent) / 3, 2),
            "based_on": [month for month, _ in recent],
            "message": "A simple average of your last three recorded expense months; not a prediction or advice."}


@app.get("/api/insights")
def insights(db: Session = Depends(get_db), user: User = Depends(current_user)):
    dashboard_data = dashboard(db, user)
    items = user_transactions(db, user.id)
    output = []
    categories = dashboard_data["category_totals"]
    if categories:
        largest = max(categories, key=lambda x: x["amount"])
        output.append({"title": "Largest recorded category",
                       "text": f"{largest['category']} is your largest recorded expense category "
                               f"at {largest['amount']:.2f} across the available history."})
    month = date.today().strftime("%Y-%m")
    for budget in db.scalars(select(Budget).where(Budget.user_id == user.id, Budget.month == month)).all():
        spent = sum(t.amount for t in items if t.type == "expense" and
                    t.date.strftime("%Y-%m") == month and
                    (not budget.category or t.category == budget.category))
        if spent > budget.amount:
            output.append({"title": "Budget over limit",
                           "text": f"{budget.category or 'Overall'} spending is {spent - budget.amount:.2f} "
                                   f"above the {budget.amount:.2f} budget."})
        elif spent >= budget.amount * 0.8:
            output.append({"title": "Budget getting close",
                           "text": f"{budget.category or 'Overall'} spending has used "
                                   f"{spent / budget.amount:.0%} of this month's budget."})
    return {"insights": output,
            "disclaimer": "Educational observations based on recorded transactions only; not professional financial advice."}


@app.post("/api/help/chat")
def help_chat(body: dict, _: User = Depends(current_user)):
    question = str(body.get("message", "")).strip().lower()[:500]
    if not question:
        raise HTTPException(422, "message is required")
    answers = [
        (("budget",), "Open Budgets to create a monthly overall or category budget. Progress is based on expenses you record."),
        (("transaction", "expense", "income"), "Use Transactions to add, search, filter, edit, or remove your manually recorded income and expenses."),
        (("category", "categor"), "Expense categories can be suggested from a description. Always review the suggestion; you can edit it."),
        (("forecast",), "The forecast uses a simple average of your last three recorded expense months and needs at least three months of history."),
        (("dashboard", "chart", "summary"), "The Dashboard summarizes the current month's income, expenses, balance, category totals, and monthly spending."),
        (("password", "login", "account", "register"), "Register with your email and a password of at least eight characters, then sign in to access your private records."),
        (("insight",), "Insights describe patterns in the transactions and budgets you entered. They are educational, not financial advice."),
    ]
    answer = next((response for keywords, response in answers if any(word in question for word in keywords)),
                  "I can help with transactions, categories, budgets, dashboard, forecast, and account usage. I cannot give individualized financial advice.")
    return {"answer": answer, "scope": "application help and general education",
            "disclaimer": "I cannot provide individualized financial advice or make transactions."}
