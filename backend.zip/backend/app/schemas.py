from datetime import date
from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator


class Credentials(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)


class UserOut(BaseModel):
    id: int
    email: EmailStr
    model_config = ConfigDict(from_attributes=True)


class AuthOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


class TransactionIn(BaseModel):
    amount: float = Field(gt=0, le=100_000_000)
    date: date
    description: str = Field(min_length=1, max_length=240)
    type: str
    category: str = Field(default="Other", min_length=1, max_length=60)

    @field_validator("type")
    @classmethod
    def valid_type(cls, value):
        if value not in ("income", "expense"):
            raise ValueError("type must be income or expense")
        return value

    @field_validator("description", "category")
    @classmethod
    def clean_text(cls, value):
        return value.strip()


class TransactionOut(TransactionIn):
    id: int
    model_config = ConfigDict(from_attributes=True)


class BudgetIn(BaseModel):
    month: str = Field(pattern=r"^\d{4}-(0[1-9]|1[0-2])$")
    amount: float = Field(gt=0, le=100_000_000)
    category: str | None = Field(default=None, max_length=60)


class BudgetOut(BudgetIn):
    id: int
    spent: float = 0
    model_config = ConfigDict(from_attributes=True)
