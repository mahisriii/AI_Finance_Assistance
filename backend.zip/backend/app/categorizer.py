"""Small educational text classifier; low-confidence predictions safely fall back to Other."""
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline

_examples = {
    "Groceries": ["supermarket grocery vegetables fruit whole foods", "market groceries food"],
    "Dining": ["restaurant cafe coffee pizza takeaway lunch dinner", "food delivery bakery"],
    "Transport": ["uber taxi bus train metro fuel gas parking", "commute ride transit"],
    "Housing": ["rent mortgage property maintenance", "electricity water internet utility bill"],
    "Shopping": ["clothes shoes online store electronics", "shopping purchase household items"],
    "Health": ["pharmacy doctor medical dentist gym", "healthcare prescription clinic"],
    "Entertainment": ["movie cinema concert streaming games", "music event tickets"],
}
_texts = [text for category, examples in _examples.items() for text in examples]
_labels = [category for category, examples in _examples.items() for _ in examples]
_model = make_pipeline(TfidfVectorizer(ngram_range=(1, 2)), LogisticRegression(max_iter=1000))
_model.fit(_texts, _labels)


def suggest_category(description: str) -> tuple[str, float]:
    probabilities = _model.predict_proba([description])[0]
    best = int(probabilities.argmax())
    confidence = float(probabilities[best])
    return (_model.classes_[best], confidence) if confidence >= 0.30 else ("Other", confidence)
