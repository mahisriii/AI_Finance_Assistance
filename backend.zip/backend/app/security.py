import base64
import hashlib
import hmac
import json
import os
import secrets
import time

from fastapi import Depends, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from .database import get_db
from .models import User

_bearer = HTTPBearer(auto_error=False)
_configured_secret = os.getenv("FINANCE_ASSISTANT_SECRET")
# An ephemeral fallback avoids shipping a predictable signing key; configure a stable
# environment secret for local sessions that should survive application restarts.
_secret = _configured_secret.encode() if _configured_secret else secrets.token_bytes(32)


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 310_000)
    return base64.urlsafe_b64encode(salt + digest).decode()


def verify_password(password: str, stored: str) -> bool:
    try:
        raw = base64.urlsafe_b64decode(stored.encode())
        expected = hashlib.pbkdf2_hmac("sha256", password.encode(), raw[:16], 310_000)
        return hmac.compare_digest(expected, raw[16:])
    except (ValueError, TypeError):
        return False


def create_token(user_id: int) -> str:
    header = _b64(json.dumps({"alg": "HS256", "typ": "JWT"}, separators=(",", ":")).encode())
    payload = _b64(json.dumps({"sub": str(user_id), "exp": int(time.time()) + 86400},
                              separators=(",", ":")).encode())
    body = f"{header}.{payload}"
    signature = _b64(hmac.new(_secret, body.encode(), hashlib.sha256).digest())
    return f"{body}.{signature}"


def _b64(value: bytes) -> str:
    return base64.urlsafe_b64encode(value).decode().rstrip("=")


def current_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(_bearer),
    db: Session = Depends(get_db),
) -> User:
    unauthorized = HTTPException(status_code=401, detail="A valid bearer token is required")
    if not credentials:
        raise unauthorized
    try:
        header, payload, signature = credentials.credentials.split(".")
        body = f"{header}.{payload}"
        expected = _b64(hmac.new(_secret, body.encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(signature, expected):
            raise unauthorized
        decoded = json.loads(base64.urlsafe_b64decode(payload + "=" * (-len(payload) % 4)))
        if int(decoded["exp"]) < time.time():
            raise unauthorized
        user = db.get(User, int(decoded["sub"]))
        if user is None:
            raise unauthorized
        return user
    except (ValueError, KeyError, TypeError, json.JSONDecodeError):
        raise unauthorized
