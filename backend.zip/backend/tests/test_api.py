import os
import tempfile

# Test database must be set before importing the application/database module.
_db_file = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
_db_file.close()
os.environ["DATABASE_URL"] = f"sqlite:///{_db_file.name}"
os.environ["FINANCE_ASSISTANT_SECRET"] = "test-key-not-for-production"

from fastapi.testclient import TestClient
from backend.app.main import app

client = TestClient(app)


def register(email):
    response = client.post("/api/auth/register", json={"email": email, "password": "correct horse"})
    assert response.status_code == 201
    return response.json()["access_token"]


def auth(token):
    return {"Authorization": f"Bearer {token}"}


def test_user_scoped_crud_budgets_forecast_and_chat():
    first = register("first@example.com")
    second = register("second@example.com")
    created = client.post("/api/transactions", headers=auth(first), json={
        "amount": 28.5, "date": "2026-11-03", "description": "coffee cafe", "type": "expense",
        "category": "Dining",
    })
    assert created.status_code == 201
    transaction = created.json()
    assert client.get("/api/transactions", headers=auth(second)).json() == []
    assert client.put(f"/api/transactions/{transaction['id']}", headers=auth(second),
                      json=transaction).status_code == 404
    assert client.delete(f"/api/transactions/{transaction['id']}", headers=auth(second)).status_code == 404
    assert client.get("/api/forecast", headers=auth(first)).json()["available"] is False
    budget = client.post("/api/budgets", headers=auth(first), json={
        "month": "2026-11", "amount": 20, "category": "Dining",
    })
    assert budget.status_code == 201
    listed = client.get("/api/budgets?month=2026-11", headers=auth(first)).json()
    assert listed[0]["spent"] == 28.5 and listed[0]["over_limit"]
    assert client.get("/api/insights", headers=auth(first)).json()["insights"]
    answer = client.post("/api/help/chat", headers=auth(first), json={"message": "How do budgets work?"})
    assert "Budgets" in answer.json()["answer"]
    assert client.get("/api/dashboard", headers=auth(first)).status_code == 200
    assert client.get("/api/transactions").status_code == 401


def test_validation_and_categorization_suggestion():
    token = register("third@example.com")
    bad = client.post("/api/transactions", headers=auth(token), json={
        "amount": -2, "date": "2026-11-03", "description": "bad", "type": "expense",
    })
    assert bad.status_code == 422
    suggestion = client.post("/api/categories/suggest?description=weekly%20grocery%20supermarket",
                             headers=auth(token))
    assert suggestion.status_code == 200
    assert suggestion.json()["category"] in {"Groceries", "Other"}


def test_auth_rejects_bad_password():
    register("fourth@example.com")
    response = client.post("/api/auth/login", json={"email": "fourth@example.com", "password": "wrong pass"})
    assert response.status_code == 401


def test_category_correction_filters_and_three_month_forecast():
    token = register("forecast@example.com")
    headers = auth(token)
    ids = []
    for month, amount in [("2026-01-15", 100), ("2026-02-15", 200), ("2026-03-15", 300)]:
        response = client.post("/api/transactions", headers=headers, json={
            "amount": amount, "date": month, "description": "misc", "type": "expense",
            "category": "Other",
        })
        assert response.status_code == 201
        ids.append(response.json()["id"])
    updated = client.put(f"/api/transactions/{ids[0]}", headers=headers, json={
        "amount": 100, "date": "2026-01-15", "description": "misc", "type": "expense",
        "category": "Groceries",
    })
    assert updated.json()["category"] == "Groceries"
    assert len(client.get("/api/transactions?category=Groceries", headers=headers).json()) == 1
    prediction = client.get("/api/forecast", headers=headers).json()
    assert prediction["available"] is True
    assert prediction["estimate"] == 200
    assert client.delete(f"/api/transactions/{ids[-1]}", headers=headers).status_code == 204
