# Integration hand-off checklist

- Backend: `backend/`; run from there with `python -m uvicorn app.main:app --reload --port 8000`; build/check: `python -m pytest tests -q`; health: `GET /api/health`.
- Frontend: `services/web/`; `npm --prefix services/web run dev`; `npm --prefix services/web run build`.
- API client seam: `services/web/src/api.js`; frontend uses live API requests already.
- Mock data: none. No mock client, sample transactions, seed data, or duplicated generated types.
- Routes: `GET /api/health`; `POST /api/auth/register`; `POST /api/auth/login`; `GET /api/auth/me`; `GET|POST /api/transactions`; `PUT|DELETE /api/transactions/{transaction_id}`; `POST /api/categories/suggest`; `GET|POST /api/budgets`; `DELETE /api/budgets/{budget_id}`; `GET /api/dashboard`; `GET /api/forecast`; `GET /api/insights`; `POST /api/help/chat`.
- Database: SQLite at `backend/finance.db`; SQLAlchemy models create tables on startup. No migration framework configured yet. `DATABASE_URL` can override the default. No seed data.
- Shared types: Pydantic response/input schemas live in `backend/app/schemas.py`; no generated shared frontend package.
- Services: FastAPI backend (Essential), React web UI (Essential), local SQLite storage (Essential), scikit-learn category suggestion (Essential).
