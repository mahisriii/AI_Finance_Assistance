# AI Finance Assistant — Project Plan

## Status

Approved for implementation by the user.

## Goal

Build a runnable, beginner-friendly personal finance application that demonstrates secure transaction management, machine-learning categorization, budgeting, analytics, a basic spending forecast, educational insights, and an application-help chatbot. The application is for educational purposes and is not professional financial advice.

## Technology

- Frontend: React
- Backend: Python with FastAPI
- Database: SQLite
- ORM and validation: SQLAlchemy and Pydantic
- Authentication: password hashing and signed bearer tokens
- Categorization: scikit-learn TF-IDF text features and a beginner-friendly classifier
- Charts: a React chart library appropriate to the scaffold
- Local-first development; cloud hosting and external financial integrations are out of scope.

## Functional scope

1. Register, log in, and access only the signed-in user's data.
2. Create, view, update, delete, search, and filter income and expense transactions, including amount, date, description, type, and category.
3. Suggest an expense category from the transaction description and allow the user to correct it.
4. Create monthly budgets, optionally by category, and show budget usage and over-limit notices.
5. Show income, expenses, balance, category totals, and monthly spending trends.
6. Estimate future monthly spending from available history; report insufficient history instead of presenting an unreliable estimate.
7. Generate understandable, data-backed spending and budget insights with an educational/non-advice disclaimer.
8. Provide an application-help chatbot limited to app usage and general educational explanations; it must not provide individualized financial advice or initiate transactions.

## Architecture and data boundaries

- Keep API routes, persistence models, business logic, and ML/analytics components separated.
- Persist users, transactions, and budgets in SQLite.
- Require authentication and user ownership checks on every user-specific record operation.
- Validate inputs and return useful error responses; do not expose credentials or sensitive data in logs.
- Use an educational sample dataset for the classifier. Keep model preprocessing and prediction separate from application logic. Use a safe manual/Other category path when data or prediction confidence is insufficient.

## Implementation sequence

1. Scaffold the repository, local developer setup, frontend, backend, and shared API contract.
2. Implement database models, authentication, authorization, and transaction CRUD/search/filter.
3. Add category prediction and user correction, budget tracking, dashboard analytics, forecasting, and insights.
4. Build and wire responsive React screens for authentication, dashboard, transactions, budgets, insights, and help.
5. Add focused backend and frontend verification, sample data, and local run instructions.

## Acceptance criteria

- The application starts locally following the documented instructions.
- Authentication protects all personal records, including against cross-user access.
- Transaction CRUD, filters, summaries, and budgets produce correct results.
- Expense categorization provides a usable prediction and supports correction/manual choice.
- Forecasting handles insufficient history explicitly.
- Insights are based on observed data and include a non-professional-advice disclaimer.
- Core flows have automated tests or the closest supported project checks.

## Out of scope

Bank/payment integrations, real-money transfers, stock trading, professional investment or tax advice, loan decisions, production cloud deployment, and administrator/dataset-management features.
